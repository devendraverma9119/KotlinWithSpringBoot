package com.kotlinspring.exception

class CourseNotFoundException(message: String) : RuntimeException(message)
